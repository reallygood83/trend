# AI 교육 뉴스 플랫폼 - 완전한 시스템 사양서 (SPEC)

> **프로젝트명**: AI Edu News - Feynman Style
> **버전**: 1.0.0
> **작성일**: 2025-11-23
> **대상 사용자**: 교사, AI 유튜버
> **목적**: 파인만 기법으로 AI/교육 뉴스를 자동 재작성하고 원클릭 발행

---

## 📋 목차

1. [프로젝트 개요](#1-프로젝트-개요)
2. [시스템 아키텍처](#2-시스템-아키텍처)
3. [기능 명세](#3-기능-명세)
4. [데이터베이스 설계](#4-데이터베이스-설계)
5. [API 명세](#5-api-명세)
6. [UI/UX 설계](#6-uiux-설계)
7. [보안 및 인증](#7-보안-및-인증)
8. [배포 및 운영](#8-배포-및-운영)
9. [비용 예측](#9-비용-예측)
10. [향후 로드맵](#10-향후-로드맵)

---

## 1. 프로젝트 개요

### 1.1 비전

**"모든 교사와 AI 유튜버가 복잡한 AI/교육 뉴스를 5분 안에 이해하고 콘텐츠로 만들 수 있게 한다"**

### 1.2 핵심 가치 제안

- ✅ **시간 절약**: 뉴스 큐레이션 + 재작성 + 발행을 원클릭으로
- 📚 **교육적 가치**: 파인만 기법으로 복잡한 내용을 누구나 이해 가능하게
- 🤖 **AI 활용**: xAI Grok-4-1-fast로 GPT-4 대비 20배 저렴한 비용
- 🌍 **다국어**: 한국어/영어 완벽 지원
- 📧 **자동화**: 뉴스레터 자동 발송, 크롤링 자동 실행

### 1.3 타겟 사용자 페르소나

#### Persona 1: 김교사 (초등학교 교사, 35세)
- **니즈**: AI 교육 도구를 수업에 활용하고 싶지만, 최신 뉴스 따라가기 어려움
- **페인 포인트**: 영어 뉴스 읽기 부담, 전문 용어 이해 어려움
- **사용 시나리오**: 매주 월요일 아침 뉴스레터로 한 주 AI 교육 트렌드 파악

#### Persona 2: 박유튜버 (AI 교육 유튜버, 28세)
- **니즈**: 주 3회 유튜브 콘텐츠 발행, 항상 새로운 주제 필요
- **페인 포인트**: 뉴스 찾기 → 이해 → 대본 작성에 하루 3-4시간 소요
- **사용 시나리오**: 관리자 대시보드에서 흥미로운 뉴스 선택 → 파인만 스타일 생성 → 대본으로 활용

### 1.4 성공 지표 (KPI)

| 지표 | 3개월 목표 | 6개월 목표 | 1년 목표 |
|------|-----------|-----------|---------|
| **구독자 수** | 500명 | 2,000명 | 10,000명 |
| **월간 활성 사용자** | 200명 | 1,000명 | 5,000명 |
| **뉴스레터 오픈율** | 30% | 35% | 40% |
| **블로그 월 방문자** | 1,000명 | 5,000명 | 20,000명 |
| **생성된 기사 수** | 90개 | 180개 | 360개 |

---

## 2. 시스템 아키텍처

### 2.1 전체 아키텍처 다이어그램

```
┌─────────────────────────────────────────────────────────────┐
│                        사용자 계층                            │
├─────────────────────────────────────────────────────────────┤
│  웹 브라우저 (Chrome, Safari, Firefox, Edge)                 │
│  - 일반 사용자: 블로그 읽기, 뉴스레터 구독                     │
│  - 관리자: 대시보드, 편집기                                   │
└─────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────┐
│                    프론트엔드 (Vercel)                        │
├─────────────────────────────────────────────────────────────┤
│  Next.js 14 (App Router)                                    │
│  ├── /[locale]                  # 다국어 라우팅 (ko/en)      │
│  ├── /[locale]/admin            # 관리자 대시보드             │
│  ├── /[locale]/posts            # 블로그 (뉴스 목록/상세)    │
│  └── /[locale]/newsletter       # 뉴스레터 구독               │
│                                                               │
│  Components:                                                  │
│  ├── AdminDashboard             # 뉴스 선택 UI               │
│  ├── FeynmanEditor              # WYSIWYG 편집기             │
│  ├── NewsCard                   # 뉴스 카드                  │
│  └── NewsletterSubscribe        # 구독 폼                    │
└─────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────┐
│                    API 계층 (Next.js API Routes)             │
├─────────────────────────────────────────────────────────────┤
│  /api/crawl              # 뉴스 크롤링 트리거                 │
│  /api/generate           # 파인만 스타일 생성                 │
│  /api/publish            # 블로그/SNS 발행                    │
│  /api/newsletter         # 구독/구독취소                      │
└─────────────────────────────────────────────────────────────┘
                             ↓
┌──────────────────┬──────────────────┬────────────────────────┐
│   Firebase       │   xAI Grok       │   External APIs        │
│   (Google)       │                  │                        │
├──────────────────┼──────────────────┼────────────────────────┤
│ Firestore        │ Grok-4-1-fast    │ Resend (Email)         │
│ - raw_news       │ (OpenAI 호환)    │ - 뉴스레터 발송         │
│ - feynman_...    │                  │                        │
│ - newsletters    │ Fallback:        │ Twitter API            │
│ - subscribers    │ - GPT-4 Turbo    │ - 트윗 발행             │
│                  │                  │                        │
│ Functions        │                  │ RSS Feeds              │
│ - crawl          │                  │ - TechCrunch           │
│ - newsletter     │                  │ - EdSurge              │
│                  │                  │ - AI타임스             │
│ Auth             │                  │                        │
│ - 관리자 인증     │                  │                        │
│                  │                  │                        │
│ Storage          │                  │                        │
│ - 이미지         │                  │                        │
└──────────────────┴──────────────────┴────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────┐
│                    외부 데이터 소스                           │
├─────────────────────────────────────────────────────────────┤
│  한국 (6개):                                                  │
│  - AI타임스, ZDNet Korea, 전자신문                            │
│  - 에듀프레스, 대학저널                                       │
│                                                               │
│  미국 (8개):                                                  │
│  - TechCrunch, VentureBeat, MIT Tech Review, The Verge      │
│  - EdSurge, eSchool News, THE Journal, EdTech Magazine      │
│                                                               │
│  추가 (선택):                                                 │
│  - Reddit (r/artificial, r/education)                        │
│  - Twitter (@OpenAI, @AnthropicAI 등)                        │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 기술 스택 상세

#### Frontend

| 기술 | 버전 | 용도 | 선택 이유 |
|------|------|------|----------|
| **Next.js** | 14.1.0 | React 프레임워크 | App Router, SSR/SSG, API Routes |
| **TypeScript** | 5.3.3 | 타입 안전성 | 대규모 프로젝트 유지보수 |
| **TailwindCSS** | 3.4.1 | 스타일링 | 빠른 개발, 일관된 디자인 |
| **shadcn/ui** | latest | UI 컴포넌트 | 커스터마이징 가능, 접근성 |
| **TipTap** | 2.1.16 | WYSIWYG 에디터 | Markdown 호환, 확장성 |
| **next-intl** | 3.7.0 | 다국어 | App Router 최적화 |

#### Backend

| 기술 | 용도 | 선택 이유 |
|------|------|----------|
| **Firebase Firestore** | NoSQL 데이터베이스 | 실시간 동기화, 무료 티어 넉넉 |
| **Firebase Functions** | 서버리스 백엔드 | 크롤링 스케줄러, 뉴스레터 발송 |
| **Firebase Auth** | 인증 | 관리자 로그인 |
| **Firebase Storage** | 파일 저장소 | 이미지 업로드 |

#### AI

| 기술 | 용도 | 비용 | 선택 이유 |
|------|------|------|----------|
| **xAI Grok-4-1-fast** | 파인만 생성 (주력) | $0.50/1M in + $1.50/1M out | GPT-4 대비 20배 저렴 |
| **OpenAI GPT-4 Turbo** | Fallback | $10/1M in + $30/1M out | 안정성 보장 |

#### Newsletter

| 기술 | 용도 | 무료 한도 |
|------|------|-----------|
| **Resend** | 이메일 발송 | 3,000 emails/month |
| **React Email** | HTML 템플릿 | - |

#### Deployment

| 서비스 | 용도 | 무료 한도 |
|--------|------|-----------|
| **Vercel** | 프론트엔드 호스팅 | 100GB 대역폭/month |
| **Firebase** | 백엔드 | 50K reads/day, 20K writes/day |

### 2.3 데이터 흐름

#### 시나리오 1: 뉴스 크롤링 → 발행

```
1. [Vercel Cron 또는 Firebase Scheduler]
   ↓ 매일 오전 9시 실행
2. [크롤러 함수]
   ↓ 한국/미국 RSS 파싱 (병렬)
3. [Firestore]
   ↓ raw_news 컬렉션에 저장 (중복 제거)
4. [관리자가 대시보드 접속]
   ↓ 오늘의 뉴스 목록 조회
5. [뉴스 선택 + "생성" 버튼 클릭]
   ↓ /api/generate 호출
6. [Grok API]
   ↓ 파인만 스타일 변환 (30-60초)
7. [Firestore]
   ↓ feynman_articles 컬렉션에 저장
8. [편집기에서 미리보기]
   ↓ 수동 편집 가능
9. ["발행" 버튼 클릭]
   ↓ /api/publish 호출
10. [블로그 발행]
    ↓ publishedAt 업데이트
11. [Twitter 발행] (선택)
    ↓ Twitter API 호출
12. [뉴스레터 대기열 추가] (선택)
    ↓ newsletters 컬렉션 업데이트
```

#### 시나리오 2: 뉴스레터 자동 발송

```
1. [Firebase Scheduler]
   ↓ 매주 일요일 오후 8시
2. [sendWeeklyNewsletter 함수]
   ↓ 이번 주 발행된 기사 조회
3. [HTML 생성]
   ↓ React Email 템플릿
4. [구독자 목록 조회]
   ↓ status='active' AND language
5. [Resend API]
   ↓ 배치 발송 (언어별)
6. [발송 기록]
   ↓ newsletters 컬렉션 업데이트
7. [통계 수집]
   ↓ openRate, clickRate
```

---

## 3. 기능 명세

### 3.1 핵심 기능 (P0 - MVP 필수)

| 기능 ID | 기능명 | 설명 | 우선순위 | 상태 |
|---------|--------|------|---------|------|
| F001 | 뉴스 크롤링 | 한국/미국 14개 소스에서 RSS 수집 | P0 | ✅ 완료 |
| F002 | 파인만 변환 | Grok API로 파인만 스타일 재작성 | P0 | ✅ 완료 |
| F003 | 관리자 대시보드 | 뉴스 선택 UI | P0 | 🚧 진행 중 |
| F004 | 편집기 | WYSIWYG 편집 + 미리보기 | P0 | 📋 예정 |
| F005 | 블로그 발행 | Firestore 저장 → Next.js 렌더링 | P0 | 📋 예정 |
| F006 | 뉴스레터 구독 | 이메일 수집 + 구독 관리 | P0 | 📋 예정 |
| F007 | 자동 발송 | 주간 뉴스레터 자동 생성/발송 | P0 | 📋 예정 |

### 3.2 부가 기능 (P1 - 출시 후 1개월 내)

| 기능 ID | 기능명 | 설명 | 우선순위 |
|---------|--------|------|---------|
| F101 | Twitter 발행 | Twitter API 연동 | P1 |
| F102 | 조회수 추적 | 기사별 조회수 카운트 | P1 |
| F103 | 검색 기능 | 키워드로 과거 기사 검색 | P1 |
| F104 | 카테고리 필터 | AI/Education/AI+Education 필터 | P1 |
| F105 | RSS 피드 | 블로그 RSS 제공 | P1 |

### 3.3 향후 기능 (P2 - 출시 후 3개월)

| 기능 ID | 기능명 | 설명 | 우선순위 |
|---------|--------|------|---------|
| F201 | Reddit/Twitter 크롤링 | 추가 소스 | P2 |
| F202 | 사용자 북마크 | 마음에 드는 기사 저장 | P2 |
| F203 | 댓글 시스템 | Disqus 또는 자체 구현 | P2 |
| F204 | 모바일 앱 | React Native | P2 |
| F205 | AI 음성 읽기 | TTS 통합 | P2 |

---

## 4. 데이터베이스 설계

### 4.1 Firestore Collections

#### Collection: `raw_news` (원본 뉴스)

```typescript
{
  id: string;                    // 문서 ID (URL 해시)
  title: string;                 // 원본 제목
  content: string;               // 원본 내용 (500자)
  source: string;                // "TechCrunch", "AI타임스" 등
  url: string;                   // 원문 링크
  publishedAt: Timestamp;        // 발행일
  crawledAt: Timestamp;          // 크롤링일

  category: "AI" | "Education" | "AI+Education";
  country: "KR" | "US";

  status: "pending" | "selected" | "processed" | "published";
  keywords: string[];            // ["AI", "교육", "ChatGPT"]
}
```

**인덱스:**
- `crawledAt DESC`
- `status + crawledAt DESC`
- `category + country + status`

#### Collection: `feynman_articles` (파인만 기사)

```typescript
{
  id: string;                    // 문서 ID
  rawNewsId: string;             // 원본 뉴스 참조

  // 파인만 콘텐츠
  feynmanTitle: string;          // "왜 AI는 우리 숙제를 도와줄 수 있을까?"
  feynmanSummary: string;        // 한 줄 요약
  feynmanContent: string;        // Markdown 본문 (800-1200자)

  // 파인만 질문 3개
  questions: [
    {
      question: string;          // "왜 이게 작동하는 거지?"
      reasoning: string;         // 파인만이 이 질문을 한 이유
      type: "principle" | "application" | "opposite";
    },
    // ... 3개
  ];

  // 메타데이터
  slug: string;                  // "why-ai-can-help-homework"
  tags: string[];                // ["AI", "교육"]
  metaDescription: string;       // SEO
  targetAudience: "teacher" | "student" | "parent";
  difficultyLevel: 1-5;
  educationContext: string;      // 교육 활용 방법

  // 타임스탬프
  createdAt: Timestamp;
  publishedAt: Timestamp | null;

  // 발행 상태
  status: "draft" | "published";
  platforms: {
    blog: { published: boolean; url: string };
    twitter?: { published: boolean; url: string };
  };

  // 뉴스레터
  includedInNewsletters: string[];  // newsletter IDs

  // 통계
  viewCount: number;
  likeCount: number;
}
```

**인덱스:**
- `publishedAt DESC`
- `status + publishedAt DESC`
- `slug` (unique)
- `tags` (array)

#### Collection: `newsletters` (뉴스레터)

```typescript
{
  id: string;
  title: string;                 // "2025년 11월 4주차 AI 교육 뉴스"
  articles: string[];            // feynman_articles IDs

  generatedAt: Timestamp;
  scheduledFor?: Timestamp;
  sentAt: Timestamp | null;

  status: "draft" | "scheduled" | "sent";

  // 통계
  subscriberCount: number;
  openCount: number;
  clickCount: number;
  openRate: number;              // openCount / subscriberCount
  clickRate: number;             // clickCount / openCount
}
```

#### Collection: `subscribers` (구독자)

```typescript
{
  id: string;
  email: string;                 // unique
  name?: string;

  subscribedAt: Timestamp;
  unsubscribedAt?: Timestamp;

  status: "active" | "unsubscribed" | "bounced";

  preferences: {
    frequency: "weekly" | "biweekly";
    categories: ("AI" | "Education" | "AI+Education")[];
    language: "ko" | "en";
  };

  // 통계
  totalOpens: number;
  totalClicks: number;
  lastOpenedAt?: Timestamp;
}
```

**인덱스:**
- `email` (unique)
- `status + preferences.language`

### 4.2 데이터 관계도

```
raw_news (1) ──> (1) feynman_articles
                        │
                        │ (M)
                        ↓
                    newsletters (M) ──> (M) subscribers
```

### 4.3 데이터 크기 예측

| 컬렉션 | 1개월 | 6개월 | 1년 |
|--------|-------|-------|-----|
| **raw_news** | 420개 (14 소스 × 30일) | 2,520개 | 5,040개 |
| **feynman_articles** | 90개 (3개/일 × 30일) | 540개 | 1,080개 |
| **newsletters** | 4개 (주간) | 24개 | 48개 |
| **subscribers** | 500명 | 2,000명 | 10,000명 |

**총 저장 용량**:
- 1년: ~500MB (텍스트 데이터)
- Firebase 무료: 1GB까지

---

## 5. API 명세

### 5.1 RESTful API Endpoints

#### POST `/api/crawl`

**설명**: 뉴스 크롤링 수동 트리거

**요청**:
```typescript
// Query Params (선택)
{
  sources?: string[];  // ["korea", "usa", "all"]
}
```

**응답**:
```typescript
{
  success: boolean;
  totalNews: number;
  newNews: number;
  errors: string[];
}
```

**예시**:
```bash
POST /api/crawl
→ { "success": true, "totalNews": 42, "newNews": 38, "errors": [] }
```

---

#### POST `/api/generate`

**설명**: 파인만 스타일 기사 생성

**요청**:
```typescript
{
  newsIds: string[];   // 최대 10개
  language: "ko" | "en";
}
```

**응답**:
```typescript
{
  success: boolean;
  articles: Array<{
    newsId: string;
    articleId: string;
    feynmanTitle: string;
  }>;
  errors: Array<{
    newsId: string;
    error: string;
  }>;
}
```

**처리 시간**: 30-60초/기사

---

#### POST `/api/publish`

**설명**: 기사 발행 (블로그 + SNS)

**요청**:
```typescript
{
  articleId: string;
  platforms: ("blog" | "twitter" | "youtube")[];
  addToNewsletter: boolean;
}
```

**응답**:
```typescript
{
  success: boolean;
  results: {
    blog?: { published: boolean; url: string };
    twitter?: { published: boolean; url?: string; error?: string };
  };
}
```

---

#### POST `/api/newsletter/subscribe`

**설명**: 뉴스레터 구독

**요청**:
```typescript
{
  email: string;
  name?: string;
  language: "ko" | "en";
  frequency: "weekly" | "biweekly";
}
```

**응답**:
```typescript
{
  success: boolean;
  message: string;
  subscriberId?: string;
}
```

---

#### POST `/api/newsletter/unsubscribe`

**설명**: 구독 취소

**요청**:
```typescript
{
  email: string;
}
```

---

### 5.2 Firebase Functions

#### Function: `scheduledCrawl`

**트리거**: Pub/Sub (매일 09:00 KST)

**동작**:
1. 한국/미국 뉴스 크롤링
2. Firestore에 저장
3. 관리자에게 Slack 알림 (선택)

---

#### Function: `sendWeeklyNewsletter`

**트리거**: Pub/Sub (매주 일요일 20:00 KST)

**동작**:
1. 이번 주 발행된 기사 조회
2. HTML 이메일 생성 (언어별)
3. Resend API로 배치 발송
4. 통계 업데이트

---

## 6. UI/UX 설계

### 6.1 화면 구성

#### 홈 페이지 (`/ko` or `/en`)

```
┌────────────────────────────────────────┐
│  [Logo] AI 교육 뉴스   [KO/EN]  [구독]  │
├────────────────────────────────────────┤
│                                        │
│  🎓 파인만 기법으로 쉽게 이해하는        │
│     AI와 교육 트렌드                    │
│                                        │
│  [이메일 입력] [뉴스레터 구독하기]      │
│                                        │
├────────────────────────────────────────┤
│  최신 뉴스 (6개)                        │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐│
│  │ 카드 1   │ │ 카드 2   │ │ 카드 3   ││
│  │ 🇰🇷 AI    │ │ 🇺🇸 Edu  │ │ 🇰🇷 AI+  ││
│  └──────────┘ └──────────┘ └──────────┘│
│  ┌──────────┐ ┌──────────┐ ┌──────────┐│
│  │ 카드 4   │ │ 카드 5   │ │ 카드 6   ││
│  └──────────┘ └──────────┘ └──────────┘│
│                                        │
│  [더 보기 →]                           │
└────────────────────────────────────────┘
```

#### 기사 상세 페이지 (`/ko/posts/[slug]`)

```
┌────────────────────────────────────────┐
│  [헤더 네비게이션]                      │
├────────────────────────────────────────┤
│                                        │
│  🤔 왜 AI는 우리 숙제를 도와줄 수 있을까?│
│  ───────────────────────────────────── │
│  📅 2025년 11월 23일 · 🇺🇸 TechCrunch  │
│  📚 난이도: ⭐⭐⭐ (중급)                │
│                                        │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━│
│                                        │
│  한 줄 요약:                           │
│  AI는 마치 무엇이든 외우는 마법 도서관...│
│                                        │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━│
│                                        │
│  [본문 Markdown]                       │
│  ## 1단계: 선택                        │
│  ...                                   │
│                                        │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━│
│                                        │
│  🎓 파인만 교수의 질문                  │
│  ┌────────────────────────────────┐  │
│  │ 1. 왜 이게 작동하는 거지?         │  │
│  │ 💡 파인만은 항상 근본 원리를...   │  │
│  └────────────────────────────────┘  │
│  ┌────────────────────────────────┐  │
│  │ 2. 이걸 어디에 쓸 수 있을까?      │  │
│  │ 💡 실용성을 중시한 파인만은...    │  │
│  └────────────────────────────────┘  │
│  ┌────────────────────────────────┐  │
│  │ 3. 만약 반대라면 어떻게 될까?     │  │
│  │ 💡 역으로 생각하는 것을...        │  │
│  └────────────────────────────────┘  │
│                                        │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━│
│                                        │
│  🏫 교육 현장 활용법                    │
│  초등학생에게는 ChatGPT를...           │
│                                        │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━│
│                                        │
│  태그: #AI #교육 #ChatGPT              │
│  공유: [Twitter] [Facebook] [복사]     │
│                                        │
└────────────────────────────────────────┘
```

#### 관리자 대시보드 (`/ko/admin`)

```
┌────────────────────────────────────────┐
│  AI 교육 뉴스 관리자                    │
│  👤 admin@example.com [로그아웃]       │
├────────────────────────────────────────┤
│  📊 대시보드                            │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐  │
│  │ 42개 │ │ 90개 │ │ 12개 │ │ 500명│  │
│  │ 뉴스 │ │ 기사 │ │ 대기 │ │ 구독 │  │
│  └──────┘ └──────┘ └──────┘ └──────┘  │
├────────────────────────────────────────┤
│  오늘의 뉴스 (42개) [새로고침] [크롤링] │
│                                        │
│  [전체선택] 필터: [AI] [교육] [KR] [US]│
│                                        │
│  ☑ ChatGPT 교육 활용 가이드 발표        │
│     🇺🇸 TechCrunch · 3시간 전 · AI     │
│                                        │
│  ☑ 서울시교육청, AI 교사 연수 확대       │
│     🇰🇷 에듀프레스 · 5시간 전 · 교육    │
│                                        │
│  □ Gemini 1.5 Pro 출시                 │
│     🇺🇸 The Verge · 6시간 전 · AI      │
│                                        │
│  ... (더 많은 뉴스)                    │
│                                        │
│  ──────────────────────────────────── │
│  선택: 2개                              │
│  [🎓 파인만 스타일로 변환 (2개)]        │
└────────────────────────────────────────┘
```

#### 편집기 (`/ko/admin/editor`)

```
┌────────────────────────────────────────┐
│  [← 뒤로] 편집기                        │
├──────────────────┬─────────────────────┤
│  편집 (왼쪽)      │  미리보기 (오른쪽)   │
│                  │                     │
│  제목:           │  [실시간 렌더링]     │
│  ┌────────────┐ │                     │
│  │왜 AI는...  │ │                     │
│  └────────────┘ │                     │
│                  │                     │
│  한 줄 요약:      │                     │
│  ┌────────────┐ │                     │
│  │AI는 마치...│ │                     │
│  └────────────┘ │                     │
│                  │                     │
│  본문 (Markdown): │                     │
│  ┌────────────┐ │                     │
│  │## 1단계    │ │                     │
│  │            │ │                     │
│  │            │ │                     │
│  └────────────┘ │                     │
│                  │                     │
│  질문 1:         │                     │
│  ┌────────────┐ │                     │
│  │왜 이게...  │ │                     │
│  └────────────┘ │                     │
│                  │                     │
│  [저장] [취소]   │                     │
├──────────────────┴─────────────────────┤
│  [← 이전] [다음 →] [🚀 발행하기]        │
└────────────────────────────────────────┘
```

### 6.2 사용자 플로우

#### 일반 사용자 플로우

```
[홈 방문] → [뉴스레터 구독] → [확인 이메일] → [구독 완료]
                ↓
[매주 일요일 8PM] → [뉴스레터 수신] → [기사 클릭] → [블로그 읽기]
```

#### 관리자 플로우 (콘텐츠 생산)

```
[로그인] → [대시보드] → [뉴스 선택 (체크박스)]
    ↓
[파인만 스타일 변환 버튼] → [30-60초 대기]
    ↓
[편집기] → [미리보기] → [수정 (선택)] → [저장]
    ↓
[발행 버튼] → [플랫폼 선택: 블로그 ✓ Twitter ✓ 뉴스레터 ✓]
    ↓
[발행 완료] → [다음 뉴스로]
```

### 6.3 반응형 디자인

| 디바이스 | 브레이크포인트 | 주요 변경사항 |
|----------|---------------|--------------|
| **Mobile** | < 768px | 1열 레이아웃, 햄버거 메뉴 |
| **Tablet** | 768px - 1024px | 2열 레이아웃 |
| **Desktop** | > 1024px | 3열 레이아웃, 사이드바 |

---

## 7. 보안 및 인증

### 7.1 관리자 인증

- **Firebase Auth** (Email/Password)
- **환경 변수**로 관리자 이메일 지정
- **미들웨어**로 `/admin` 경로 보호

```typescript
// middleware.ts
export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (pathname.startsWith('/admin')) {
    const session = await getSession(request);

    if (!session || session.email !== process.env.ADMIN_EMAIL) {
      return NextResponse.redirect(new URL('/login', request.url));
    }
  }

  return NextResponse.next();
}
```

### 7.2 API 보안

- **CORS 설정**: Vercel 도메인만 허용
- **Rate Limiting**: 1분당 10 requests
- **API 키 검증**: Vercel Edge Config

### 7.3 데이터 보호

- **Firestore Rules**:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // 읽기: 모두 허용 (발행된 기사)
    match /feynman_articles/{article} {
      allow read: if resource.data.status == 'published';
      allow write: if request.auth.token.email == 'admin@example.com';
    }

    // 구독자: 본인만 읽기
    match /subscribers/{subscriber} {
      allow read: if request.auth != null && request.auth.uid == subscriber;
      allow create: if true; // 구독 허용
      allow update, delete: if request.auth.uid == subscriber;
    }

    // 나머지: 관리자만
    match /{document=**} {
      allow read, write: if request.auth.token.email == 'admin@example.com';
    }
  }
}
```

---

## 8. 배포 및 운영

### 8.1 Vercel 배포

**vercel.json**:
```json
{
  "crons": [
    {
      "path": "/api/crawl",
      "schedule": "0 9 * * *"
    }
  ],
  "env": {
    "NEXT_PUBLIC_FIREBASE_API_KEY": "@firebase-api-key",
    "XAI_API_KEY": "@xai-api-key"
  }
}
```

**배포 명령어**:
```bash
# 프로덕션 배포
vercel --prod

# 환경 변수 설정
vercel env add NEXT_PUBLIC_FIREBASE_API_KEY production
vercel env add XAI_API_KEY production
```

### 8.2 Firebase 배포

**firebase.json**:
```json
{
  "functions": {
    "source": "functions",
    "runtime": "nodejs18"
  },
  "firestore": {
    "rules": "firestore.rules"
  }
}
```

**배포 명령어**:
```bash
# Functions + Firestore Rules
firebase deploy --only functions,firestore:rules
```

### 8.3 모니터링

- **Vercel Analytics**: 페이지 뷰, 성능
- **Firebase Console**: Firestore 사용량, Functions 실행
- **Sentry** (선택): 에러 추적

### 8.4 백업

- **Firestore Export** (매주 일요일 자동)
```bash
firebase functions:deploy backupFirestore
```

---

## 9. 비용 예측

### 9.1 월간 비용 (구독자 1,000명 기준)

| 서비스 | 사용량 | 무료 한도 | 초과 비용 | 월 비용 |
|--------|--------|-----------|----------|---------|
| **Vercel** | 100GB 대역폭 | 100GB | - | $0 |
| **Firebase Firestore** | 30K reads/day | 50K/day | - | $0 |
| **Firebase Functions** | 60 invocations/month | 2M/month | - | $0 |
| **xAI Grok** | 90 기사/월 | - | ~500K tokens | $15 |
| **Resend** | 4,000 emails/month | 3,000 | 1,000 초과 | $5 |
| **OpenAI GPT-4** (Fallback) | 10 기사/월 | - | ~100K tokens | $5 |
| **총계** | | | | **$25/월** |

### 9.2 확장 시나리오 (구독자 10,000명)

| 서비스 | 월 비용 |
|--------|---------|
| Vercel | $20 (Pro Plan) |
| Firebase | $50 (Blaze Plan) |
| Grok | $30 |
| Resend | $50 (50K emails) |
| **총계** | **$150/월** |

---

## 10. 향후 로드맵

### 10.1 Q1 2026 (출시 후 3개월)

- [ ] Reddit/Twitter 크롤링 추가
- [ ] 사용자 댓글 시스템 (Disqus)
- [ ] 모바일 최적화
- [ ] 검색 기능 (Algolia)
- [ ] RSS 피드 제공

### 10.2 Q2 2026 (출시 후 6개월)

- [ ] 사용자 계정 시스템 (북마크, 읽기 목록)
- [ ] 프리미엄 기능 (월 $5)
  - 광고 제거
  - 독점 콘텐츠
  - PDF 다운로드
- [ ] 모바일 앱 (React Native)

### 10.3 Q3 2026 (출시 후 9개월)

- [ ] AI 음성 읽기 (TTS)
- [ ] 유튜브 쇼츠 자동 생성
- [ ] 커뮤니티 기능 (포럼)
- [ ] API 제공 (for 3rd party)

---

## 📝 변경 이력

| 버전 | 날짜 | 변경 내용 | 작성자 |
|------|------|----------|--------|
| 1.0.0 | 2025-11-23 | 초안 작성 | Claude (Anthropic) |

---

## 📞 문의

- **GitHub**: [reallygood83/masteroflearning](https://github.com/reallygood83/masteroflearning)
- **Email**: your-email@example.com

---

**끝**
